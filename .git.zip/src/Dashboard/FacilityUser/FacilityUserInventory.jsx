import React, { useState, useEffect } from 'react';
import { 
  FaSearch, FaFileCsv, FaFilePdf, FaBox, FaExclamationTriangle 
} from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import BaseUrl from '../../Api/BaseUrl';

const FacilityUserInventory = () => {
  const [inventoryData, setInventoryData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [facilityId, setFacilityId] = useState(null);

  const baseUrl = BaseUrl;
  
  useEffect(() => {
    const userStr = localStorage.getItem('user') || 
                    localStorage.getItem('userData') || 
                    localStorage.getItem('authUser');

    if (userStr) {
      try {
        const user = JSON.parse(userStr);
        if (user && user.facility_id) {
          setFacilityId(user.facility_id);
          return;
        }
      } catch (e) {
        console.error('Failed to parse user', e);
      }
    }
    setError('Facility ID not found. Please log in as a facility user.');
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!facilityId) return;

    const fetchInventoryData = async () => {
      setLoading(true);
      setError(null);

      try {
        const response = await axios.get(`${baseUrl}/inventory/${facilityId}`);

        if (response.data?.success) {
          let rawData = response.data.data;

          // ✅ Handle both single object and array
          const items = Array.isArray(rawData) 
            ? rawData 
            : (rawData && typeof rawData === 'object' ? [rawData] : []);

          const transformedData = items.map(item => ({
            id: item.id,
            itemName: item.item_name || 'Unnamed Item',
            category: item.category || 'Medicines',
            batch: item.item_code || 'B001',
            lot: `L-${item.id}`,
            expiryDate: item.updated_at ? item.updated_at.split('T')[0] : 'N/A',
            availableQty: item.quantity || 0,
            remarks: item.description || '-'
          }));

          setInventoryData(transformedData);
          setFilteredData(transformedData);
        } else {
          setInventoryData([]);
          setFilteredData([]);
        }
      } catch (err) {
        setError('Failed to fetch inventory data.');
        console.error('Error:', err);
        setInventoryData([]);
        setFilteredData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchInventoryData();
  }, [facilityId, baseUrl]);

  useEffect(() => {
    if (!searchTerm.trim()) {
      setFilteredData(inventoryData);
    } else {
      const term = searchTerm.toLowerCase();
      const filtered = inventoryData.filter(item =>
        item.itemName.toLowerCase().includes(term) ||
        item.category.toLowerCase().includes(term) ||
        item.batch.toLowerCase().includes(term) ||
        item.lot.toLowerCase().includes(term)
      );
      setFilteredData(filtered);
    }
  }, [searchTerm, inventoryData]);

  const handleExportCSV = () => alert('Exporting data to CSV');
  const handleExportPDF = () => alert('Exporting data to PDF');

  const getExpiryStatus = (expiryDate, qty) => {
    if (qty === 0) return { text: "Out of Stock", class: "bg-danger" };
    if (expiryDate === 'N/A') return { text: "No Expiry", class: "bg-secondary" };

    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffDays = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return { text: "Expired", class: "bg-danger" };
    if (diffDays <= 30) return { text: "Expiring Soon", class: "bg-warning text-dark" };
    if (diffDays <= 90) return { text: "Near Expiry", class: "bg-info text-dark" };
    return { text: "In Stock", class: "bg-success" };
  };

  return (
    <div className="container-fluid py-4 px-3 px-md-4">
      <h2 className="mb-4">Facility Inventory</h2>

      {error && (
        <div className="alert alert-danger d-flex align-items-center" role="alert">
          <FaExclamationTriangle className="me-2" />
          <div>{error}</div>
        </div>
      )}

      <div className="card border-0 shadow-sm mb-4">
        <div className="card-body d-flex flex-wrap justify-content-between gap-2">
          <div className="input-group" style={{ maxWidth: '300px' }}>
            <span className="input-group-text"><FaSearch /></span>
            <input 
              type="text" 
              className="form-control" 
              placeholder="Search by item name, batch, lot..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="d-flex gap-2">
            <button className="btn btn-outline-success" onClick={handleExportCSV}>
              <FaFileCsv /> CSV
            </button>
            <button className="btn btn-outline-danger" onClick={handleExportPDF}>
              <FaFilePdf /> PDF
            </button>
          </div>
        </div>
      </div>

      <div className="card border-0 shadow-sm">
        <div className="card-body p-0">
          {loading ? (
            <div className="text-center py-5">
              <div className="spinner-border text-primary"></div>
              <p className="mt-2 text-muted">Loading inventory data...</p>
            </div>
          ) : (
            <div className="table-responsive">
              <table className="table table-hover mb-0">
                <thead className="table-light">
                  <tr>
                    <th>Item Name</th>
                    <th>Category</th>
                    <th>Batch / Lot</th>
                    <th>Expiry Date</th>
                    <th>Available Qty</th>
                    <th>Status</th>
                    <th>Remarks</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredData.length > 0 ? (
                    filteredData.map((item) => {
                      const status = getExpiryStatus(item.expiryDate, item.availableQty);
                      return (
                        <tr key={item.id}>
                          <td>{item.itemName}</td>
                          <td>{item.category}</td>
                          <td>{item.batch} / {item.lot}</td>
                          <td>
                            {item.expiryDate === 'N/A' 
                              ? 'N/A' 
                              : new Date(item.expiryDate).toLocaleDateString()}
                          </td>
                          <td>{item.availableQty}</td>
                          <td>
                            <span className={`badge ${status.class} rounded-pill px-2 py-1`}>
                              {status.text}
                            </span>
                          </td>
                          <td>{item.remarks}</td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan="7" className="text-center py-4 text-muted">
                        <FaBox size={20} className="me-2" />
                        No inventory items found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FacilityUserInventory;