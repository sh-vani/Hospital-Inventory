

const BaseUrl = 'https://hospitalinventory-backend-production.up.railway.app/api';
// const BaseUrl = 'https://ssknf82q-3000.inc1.devtunnels.ms/api';
export default BaseUrl;