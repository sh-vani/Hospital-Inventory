
const BaseUrl = 'https://ssknf82q-4000.inc1.devtunnels.ms/api';

// const BaseUrl = 'https://g5kqw2tn-5000.inc1.devtunnels.ms/api';

export default BaseUrl;